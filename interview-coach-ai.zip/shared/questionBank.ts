export type QuestionPrompt = {
  question: string;
  intent: string;
  category: "Technical" | "Behavioral";
  tip: string;
};

export const QUESTION_BANK: Record<string, QuestionPrompt[]> = {
  "Frontend Engineer": [
    { question: "Tell me about a frontend performance problem you diagnosed and how you fixed it.", intent: "Looks for a structured debugging story and measurable impact.", category: "Technical", tip: "Use Situation → Diagnosis → Fix → Result." },
    { question: "How would you design a reusable component system for a growing product team?", intent: "Looks for API design, consistency, and maintainability.", category: "Technical", tip: "Discuss boundaries, accessibility, documentation, and versioning." },
    { question: "How do you decide whether a piece of state belongs locally or globally?", intent: "Looks for practical state-management judgment.", category: "Technical", tip: "Give a concrete example and mention ownership and update frequency." },
    { question: "Describe a time you improved the accessibility of a web experience.", intent: "Looks for empathy, standards awareness, and measurable improvement.", category: "Behavioral", tip: "Mention the users affected, the change, and how you verified it." },
    { question: "How would you investigate a layout that works on desktop but breaks on mobile?", intent: "Looks for systematic responsive debugging.", category: "Technical", tip: "Start with reproduction, isolate the constraint, then verify across breakpoints." },
    { question: "What makes a frontend codebase easy for another engineer to change safely?", intent: "Looks for engineering quality and team habits.", category: "Behavioral", tip: "Cover tests, naming, component boundaries, and clear documentation." },
    { question: "How would you reduce the time to interactive on a content-heavy page?", intent: "Looks for prioritization across loading, rendering, and runtime work.", category: "Technical", tip: "Separate the critical path from deferred work and name the metrics." },
    { question: "Tell me about a frontend tradeoff you made that you would make differently now.", intent: "Looks for reflection and technical judgment.", category: "Behavioral", tip: "Explain the context, tradeoff, result, and lesson." },
  ],
  "Backend Engineer": [
    { question: "How would you design an API that remains reliable as traffic grows tenfold?", intent: "Looks for scalability, observability, and failure-mode thinking.", category: "Technical", tip: "Discuss bottlenecks, caching, rate limits, and graceful degradation." },
    { question: "Tell me about a production incident you helped investigate.", intent: "Looks for ownership, calm debugging, and learning.", category: "Behavioral", tip: "Cover detection, mitigation, root cause, and prevention." },
    { question: "When would you choose an asynchronous workflow over a synchronous request?", intent: "Looks for latency and consistency tradeoffs.", category: "Technical", tip: "Use a concrete user flow and explain retries and idempotency." },
    { question: "How do you design an endpoint so retrying it does not create duplicate work?", intent: "Looks for idempotency and distributed-systems awareness.", category: "Technical", tip: "Mention keys, state transitions, and safe failure handling." },
    { question: "How would you migrate a large database table with minimal downtime?", intent: "Looks for rollout safety and operational planning.", category: "Technical", tip: "Describe expand-and-contract, backfills, and monitoring." },
    { question: "Describe a time you disagreed with an API or architecture decision.", intent: "Looks for technical communication and collaboration.", category: "Behavioral", tip: "Explain how you used evidence and aligned on a decision." },
    { question: "What signals tell you that a backend service needs to be split or consolidated?", intent: "Looks for pragmatic architecture rather than ideology.", category: "Technical", tip: "Discuss ownership, coupling, deployability, and operational cost." },
    { question: "How would you protect a public API from abuse without hurting legitimate users?", intent: "Looks for security and product-aware rate limiting.", category: "Technical", tip: "Balance identity, quotas, detection, and useful error responses." },
  ],
  "Software Engineer": [
    { question: "Tell me about a complex bug you solved and how you narrowed down the cause.", intent: "Looks for debugging discipline and clarity.", category: "Technical", tip: "Walk through hypotheses, experiments, and the final fix." },
    { question: "How do you decide what to test at the unit, integration, and end-to-end levels?", intent: "Looks for balanced quality strategy.", category: "Technical", tip: "Discuss confidence, speed, ownership, and failure boundaries." },
    { question: "Describe a time you improved a team’s development process.", intent: "Looks for initiative and sustainable impact.", category: "Behavioral", tip: "Name the friction, intervention, adoption, and result." },
    { question: "How would you approach learning an unfamiliar codebase in your first week?", intent: "Looks for structured onboarding and curiosity.", category: "Behavioral", tip: "Mention users, architecture, local setup, tests, and small changes." },
    { question: "What makes a code review useful rather than merely correct?", intent: "Looks for collaboration and engineering judgment.", category: "Behavioral", tip: "Discuss signal, context, tone, and shared standards." },
    { question: "How would you choose between a simple solution now and a more extensible one?", intent: "Looks for proportional tradeoff analysis.", category: "Technical", tip: "Tie the choice to uncertainty, reversibility, and expected change." },
    { question: "Tell me about a time you had to deliver under an aggressive deadline.", intent: "Looks for prioritization without sacrificing critical quality.", category: "Behavioral", tip: "Explain what you cut, what you protected, and the outcome." },
    { question: "How do you make technical decisions visible and understandable to the team?", intent: "Looks for written communication and alignment.", category: "Behavioral", tip: "Mention decision records, alternatives, and follow-up signals." },
  ],
  "Product Designer": [
    { question: "Walk me through a design decision where user research changed your original direction.", intent: "Looks for curiosity, tradeoffs, and evidence-led thinking.", category: "Behavioral", tip: "Name the insight, the pivot, and what improved after launch." },
    { question: "How would you improve a checkout flow with a high abandonment rate?", intent: "Looks for problem framing and iterative design.", category: "Technical", tip: "Combine analytics, research, prototypes, and experiment design." },
    { question: "Tell me about a time you resolved disagreement with a product or engineering partner.", intent: "Looks for collaboration and influence.", category: "Behavioral", tip: "Focus on the shared goal and how evidence shaped the outcome." },
    { question: "How do you decide when a design is ready to ship?", intent: "Looks for quality, risk, and iteration judgment.", category: "Technical", tip: "Mention usability, accessibility, edge cases, and product goals." },
    { question: "How would you design an empty state for a new user with no data yet?", intent: "Looks for onboarding and motivation thinking.", category: "Technical", tip: "Explain the user’s next best action and how you avoid dead ends." },
    { question: "Describe a project where you had to simplify a complicated experience.", intent: "Looks for information architecture and prioritization.", category: "Behavioral", tip: "Explain what you removed, preserved, and measured." },
    { question: "How do you use a design system without making every experience feel identical?", intent: "Looks for systems thinking with intentional flexibility.", category: "Technical", tip: "Discuss principles, tokens, components, and meaningful variation." },
    { question: "What is a design mistake you learned the most from?", intent: "Looks for reflection and growth.", category: "Behavioral", tip: "Be specific about the assumption, evidence, and changed practice." },
  ],
  "Data Analyst": [
    { question: "How would you investigate a sudden 20% drop in weekly active users?", intent: "Looks for hypothesis-driven analysis and communication.", category: "Technical", tip: "Validate the data, segment the change, then test likely causes." },
    { question: "Tell me about a time your analysis changed a business decision.", intent: "Looks for influence and translating analysis into action.", category: "Behavioral", tip: "Explain the decision, insight, recommendation, and result." },
    { question: "How would you define a north-star metric for a new product?", intent: "Looks for connection between user value and measurement.", category: "Technical", tip: "Start with the product’s value exchange and add guardrail metrics." },
    { question: "How do you check whether a dataset is trustworthy before analyzing it?", intent: "Looks for data-quality discipline.", category: "Technical", tip: "Mention completeness, consistency, freshness, definitions, and sampling." },
    { question: "How would you explain a statistically significant result to a nontechnical stakeholder?", intent: "Looks for clear communication without overstating certainty.", category: "Behavioral", tip: "Use plain language, effect size, uncertainty, and practical meaning." },
    { question: "Describe a time two dashboards reported different numbers.", intent: "Looks for investigation and metric governance.", category: "Behavioral", tip: "Trace definitions, filters, sources, and agree on ownership." },
    { question: "How would you evaluate whether a product experiment was successful?", intent: "Looks for experiment design and decision-making.", category: "Technical", tip: "Cover hypothesis, primary metric, guardrails, duration, and action." },
    { question: "What would you do if a stakeholder asked you to present only favorable data?", intent: "Looks for integrity and constructive pushback.", category: "Behavioral", tip: "Protect accuracy while offering a balanced, decision-ready view." },
  ],
  "ML Engineer": [
    { question: "How would you monitor a machine-learning model after deploying it?", intent: "Looks for production awareness beyond offline accuracy.", category: "Technical", tip: "Discuss data drift, performance, latency, quality, and alerts." },
    { question: "Tell me about a model that performed well offline but poorly in production.", intent: "Looks for diagnosis of train-serve and distribution issues.", category: "Behavioral", tip: "Explain the mismatch, evidence, fix, and prevention." },
    { question: "How would you choose a baseline for a new prediction problem?", intent: "Looks for pragmatic modeling and evaluation.", category: "Technical", tip: "Start simple, define the metric, and establish a meaningful comparison." },
    { question: "What steps would you take to reduce data leakage in a training pipeline?", intent: "Looks for rigorous validation thinking.", category: "Technical", tip: "Separate time, features, transforms, and evaluation data carefully." },
    { question: "How do you decide whether a model should be retrained?", intent: "Looks for operational thresholds and cost awareness.", category: "Technical", tip: "Combine drift, quality, business impact, and retraining cost." },
    { question: "Describe a time you communicated a model limitation to a stakeholder.", intent: "Looks for responsible and understandable communication.", category: "Behavioral", tip: "Frame the limitation, risk, alternative, and recommendation." },
    { question: "How would you improve inference latency for a model serving endpoint?", intent: "Looks for practical optimization tradeoffs.", category: "Technical", tip: "Consider profiling, batching, caching, compression, and quality impact." },
    { question: "How would you test whether a model is fair across important user groups?", intent: "Looks for evaluation design and responsible ML.", category: "Technical", tip: "Define groups, metrics, sample sizes, and mitigation options." },
  ],
  "Product Manager": [
    { question: "Tell me about a time you had to say no to a high-priority stakeholder.", intent: "Looks for prioritization, empathy, and clear decision-making.", category: "Behavioral", tip: "Explain the criteria you used, not just the outcome." },
    { question: "How would you prioritize three customer problems with limited engineering capacity?", intent: "Looks for structured prioritization and tradeoffs.", category: "Technical", tip: "Use impact, confidence, effort, urgency, and strategic fit." },
    { question: "How would you define success for a new onboarding experience?", intent: "Looks for product goals and measurable outcomes.", category: "Technical", tip: "Connect activation, retention, quality, and guardrail metrics." },
    { question: "Describe a product decision you made with incomplete information.", intent: "Looks for judgment under uncertainty.", category: "Behavioral", tip: "Explain assumptions, reversible steps, and what you learned." },
    { question: "How would you investigate a feature with high adoption but low retention?", intent: "Looks for funnel analysis and user understanding.", category: "Technical", tip: "Segment users, inspect value realization, and test hypotheses." },
    { question: "What would you do if engineering estimated a roadmap item at twice the expected effort?", intent: "Looks for collaboration and scope judgment.", category: "Behavioral", tip: "Clarify drivers, revisit value, and find a thinner learning slice." },
    { question: "How do you turn qualitative customer feedback into a product decision?", intent: "Looks for synthesis rather than anecdote-driven roadmaps.", category: "Technical", tip: "Cluster themes, size the problem, and triangulate with behavior." },
    { question: "Tell me about a product launch that did not go as planned.", intent: "Looks for accountability and learning.", category: "Behavioral", tip: "Own the gap, explain the response, and show what changed." },
  ],
  "DevOps Engineer": [
    { question: "How would you improve the reliability of a deployment pipeline?", intent: "Looks for automation, safety, and observability.", category: "Technical", tip: "Discuss tests, progressive delivery, rollback, and ownership." },
    { question: "Tell me about an outage you helped resolve.", intent: "Looks for incident leadership and learning.", category: "Behavioral", tip: "Cover mitigation, communication, root cause, and follow-up." },
    { question: "How would you choose between horizontal and vertical scaling for a service?", intent: "Looks for capacity and architecture judgment.", category: "Technical", tip: "Tie the choice to workload shape, bottlenecks, and cost." },
    { question: "What should a useful service-level objective include?", intent: "Looks for reliability as a user-centered practice.", category: "Technical", tip: "Define a meaningful indicator, target, window, and error budget." },
    { question: "How would you secure secrets across development and production?", intent: "Looks for practical security and operational hygiene.", category: "Technical", tip: "Mention a secret manager, least privilege, rotation, and auditability." },
    { question: "Describe a time you reduced operational toil for your team.", intent: "Looks for automation with measurable impact.", category: "Behavioral", tip: "Name the repeated pain, automation, and hours or errors saved." },
    { question: "How would you investigate a gradual increase in API latency?", intent: "Looks for observability-led debugging.", category: "Technical", tip: "Compare baselines, segment traces, and isolate the changing dependency." },
    { question: "How do you balance deployment speed with production safety?", intent: "Looks for mature risk management.", category: "Behavioral", tip: "Discuss small changes, automation, progressive rollout, and rollback." },
  ],
  "Cybersecurity Analyst": [
    { question: "How would you triage a suspected phishing incident?", intent: "Looks for prioritization, containment, and evidence handling.", category: "Technical", tip: "Start with scope, affected accounts, containment, and communication." },
    { question: "Tell me about a time you found and reduced a security risk.", intent: "Looks for ownership and practical mitigation.", category: "Behavioral", tip: "Explain discovery, risk assessment, fix, and verification." },
    { question: "How would you investigate an unusual login from a new location?", intent: "Looks for identity, context, and false-positive reasoning.", category: "Technical", tip: "Check device, timing, behavior, authentication signals, and user confirmation." },
    { question: "What makes a vulnerability high priority?", intent: "Looks for risk-based remediation rather than severity-only thinking.", category: "Technical", tip: "Combine exploitability, exposure, impact, and compensating controls." },
    { question: "How would you explain a security control to a nontechnical team?", intent: "Looks for clear, collaborative security communication.", category: "Behavioral", tip: "Connect the control to a real risk and an easy user action." },
    { question: "How do you avoid overwhelming a team with security alerts?", intent: "Looks for detection quality and operational prioritization.", category: "Technical", tip: "Tune signals, deduplicate, enrich context, and define response tiers." },
    { question: "Describe a time you had to make a security recommendation without perfect data.", intent: "Looks for judgment under uncertainty.", category: "Behavioral", tip: "State assumptions, choose a reversible action, and define follow-up evidence." },
    { question: "How would you assess the security risk of a new third-party vendor?", intent: "Looks for structured due diligence.", category: "Technical", tip: "Cover data access, controls, evidence, contract terms, and monitoring." },
  ],
};

export type Difficulty = "warmup" | "standard" | "stretch";

const difficultyPrompts: Record<Difficulty, Array<{ question: string; intent: string; category: "Technical" | "Behavioral"; tip: string }>> = {
  warmup: [
    { question: "What does success look like in this role, and how would you measure it in a college or personal project?", intent: "Looks for clear fundamentals and outcome awareness.", category: "Behavioral", tip: "Use coursework, an academic project, internship, hackathon, or personal project." },
    { question: "Walk me through a typical problem you would solve in this role.", intent: "Looks for practical understanding without requiring work experience.", category: "Technical", tip: "Use a class assignment or personal project and explain your steps." },
    { question: "Tell me about a college, internship, hackathon, volunteer, or personal project you are proud of.", intent: "Looks for ownership and clear communication.", category: "Behavioral", tip: "Focus on your contribution, challenge, and result." },
    { question: "How do you organize your work when you have several priorities?", intent: "Looks for basic prioritization habits.", category: "Behavioral", tip: "Mention the criteria and communication you use." },
    { question: "What is one tool or practice that helps you do college or project work better?", intent: "Looks for self-awareness and practical fluency.", category: "Technical", tip: "Explain the problem it solves rather than only naming it." },
    { question: "Describe a time a teacher, mentor, teammate, or reviewer gave you useful feedback.", intent: "Looks for coachability and reflection.", category: "Behavioral", tip: "Share what changed in your work afterward." },
    { question: "How would you explain a project you built to a nontechnical teammate?", intent: "Looks for accessible communication.", category: "Behavioral", tip: "Use plain language and connect the project to its users." },
    { question: "What would you want to learn in your first month in this role?", intent: "Looks for curiosity and an intentional ramp-up plan.", category: "Behavioral", tip: "Name the people, systems, and outcomes you would prioritize." },
  ],
  standard: [
    { question: "Tell me about a difficult problem you solved in a project, course, internship, or hackathon and the tradeoff behind your solution.", intent: "Looks for structured reasoning and judgment.", category: "Behavioral", tip: "Explain the context, options, decision, and result. Freshers can use academic or personal projects." },
    { question: "How would you investigate a key metric moving in the wrong direction?", intent: "Looks for hypothesis-driven problem solving.", category: "Technical", tip: "Validate the data, segment the change, and test likely causes." },
    { question: "Describe a time you helped a teammate or project group agree on a decision.", intent: "Looks for communication and collaboration.", category: "Behavioral", tip: "Use a class, club, hackathon, internship, or personal project example." },
    { question: "How do you decide between a fast solution and a more scalable one?", intent: "Looks for proportional tradeoff analysis.", category: "Technical", tip: "Tie the choice to uncertainty, reversibility, and expected change." },
    { question: "Tell me about a college, internship, hackathon, or personal project that did not go as planned.", intent: "Looks for accountability and learning.", category: "Behavioral", tip: "Own the gap, explain your response, and name the lesson." },
    { question: "How would you improve an existing workflow with limited time and resources?", intent: "Looks for prioritization and measurable improvement.", category: "Technical", tip: "Find the biggest friction, test a small change, and measure it." },
    { question: "Describe a disagreement with a classmate, teammate, mentor, or project partner and how you resolved it.", intent: "Looks for collaboration under tension.", category: "Behavioral", tip: "Focus on the shared goal and what you changed." },
    { question: "What signals tell you that a solution is ready to ship?", intent: "Looks for quality and risk judgment.", category: "Technical", tip: "Mention user value, edge cases, validation, and monitoring." },
  ],
  stretch: [
    { question: "How would you redesign a critical part of the system or process if its scale doubled next year?", intent: "Looks for systems thinking and long-term tradeoffs.", category: "Technical", tip: "State assumptions, identify bottlenecks, and define success metrics." },
    { question: "Describe a high-stakes decision you made, or would make in a project, with incomplete information.", intent: "Looks for judgment under uncertainty.", category: "Behavioral", tip: "Freshers can use a project or hypothetical scenario; explain assumptions and risk reduction." },
    { question: "How would you evaluate whether a proposed improvement created unintended harm?", intent: "Looks for balanced measurement and risk awareness.", category: "Technical", tip: "Pair the primary metric with guardrails and user feedback." },
    { question: "Describe a time you changed your mind after seeing new evidence in a project, assignment, or debate.", intent: "Looks for intellectual honesty and adaptability.", category: "Behavioral", tip: "Make the evidence and decision change explicit." },
    { question: "How would you align teams that disagree on the right long-term direction?", intent: "Looks for strategy, facilitation, and decision ownership.", category: "Behavioral", tip: "Create shared criteria, expose tradeoffs, and close with a decision." },
    { question: "What is the hardest risk in this role to detect early, and how would you monitor it?", intent: "Looks for anticipatory thinking and leading indicators.", category: "Technical", tip: "Name the failure mode, signal, threshold, and response." },
    { question: "How would you make a recommendation when the data is noisy and stakeholders want certainty?", intent: "Looks for analytical integrity and executive communication.", category: "Technical", tip: "Separate facts, confidence, assumptions, and the next learning step." },
    { question: "What important tradeoff would you refuse to hide from a user, teammate, or project stakeholder?", intent: "Looks for values, transparency, and mature judgment.", category: "Behavioral", tip: "Use a project example or explain how you would communicate it." },
  ],
};

export function getQuestionPool(role: string, difficulty: Difficulty = "standard"): QuestionPrompt[] {
  const roleQuestions = QUESTION_BANK[role] ?? [];
  if (difficulty === "standard" && roleQuestions.length) return roleQuestions.map(question => ({
    ...question,
    tip: `${question.tip} Freshers can use coursework, internships, hackathons, or personal projects.`,
  }));
  return difficultyPrompts[difficulty].map(question => ({
    ...question,
    question: `${question.question} (${role})`,
  }));
}
