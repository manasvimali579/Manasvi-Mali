import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const interviewSessions = mysqlTable("interview_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  role: varchar("role", { length: 120 }).notNull(),
  interviewType: mysqlEnum("interviewType", ["technical", "behavioral", "mixed"]).default("mixed").notNull(),
  difficulty: mysqlEnum("difficulty", ["warmup", "standard", "stretch"]).default("standard").notNull(),
  score: int("score"),
  questionCount: int("questionCount").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const interviewAnswers = mysqlTable("interview_answers", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId"),
  userId: int("userId"),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  clarity: int("clarity").notNull(),
  relevance: int("relevance").notNull(),
  confidence: int("confidence").notNull(),
  technicalAccuracy: int("technicalAccuracy").notNull(),
  overall: int("overall").notNull(),
  feedback: text("feedback").notNull(),
  strengths: text("strengths").notNull(),
  improvements: text("improvements").notNull(),
  followUp: text("followUp").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type InterviewSession = typeof interviewSessions.$inferSelect;
export type InterviewAnswer = typeof interviewAnswers.$inferSelect;
