CREATE TABLE `interview_answers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int,
	`userId` int,
	`question` text NOT NULL,
	`answer` text NOT NULL,
	`clarity` int NOT NULL,
	`relevance` int NOT NULL,
	`confidence` int NOT NULL,
	`technicalAccuracy` int NOT NULL,
	`overall` int NOT NULL,
	`feedback` text NOT NULL,
	`strengths` text NOT NULL,
	`improvements` text NOT NULL,
	`followUp` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `interview_answers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `interview_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`role` varchar(120) NOT NULL,
	`interviewType` enum('technical','behavioral','mixed') NOT NULL DEFAULT 'mixed',
	`difficulty` enum('warmup','standard','stretch') NOT NULL DEFAULT 'standard',
	`score` int,
	`questionCount` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `interview_sessions_id` PRIMARY KEY(`id`)
);
