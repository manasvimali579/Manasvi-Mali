import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { fallbackForRole } from "./routers/interview";
import type { TrpcContext } from "./_core/context";
import { getQuestionPool } from "@shared/questionBank";

const context = {
  user: null,
  req: {} as TrpcContext["req"],
  res: {} as TrpcContext["res"],
} satisfies TrpcContext;

describe("interview coach", () => {
  it("provides a role-specific fallback question", () => {
    const question = fallbackForRole("Frontend Engineer", [], 0);
    expect(question.category).toBe("Technical");
    expect(question.question).toContain("frontend performance");
    expect(question.tip).toContain("Situation");
  });

  it("selects a different fallback when the current question is excluded", () => {
    const first = fallbackForRole("Frontend Engineer", [], 0);
    const next = fallbackForRole("Frontend Engineer", [first.question], 0);
    const third = fallbackForRole("Frontend Engineer", [first.question, next.question], 0);
    expect(next.question).not.toBe(first.question);
    expect(third.question).not.toBe(first.question);
    expect(third.question).not.toBe(next.question);
  });

  it("provides eight unique instant questions for every supported role", () => {
    ["Frontend Engineer", "Backend Engineer", "Software Engineer", "Product Designer", "Data Analyst", "ML Engineer", "Product Manager", "DevOps Engineer", "Cybersecurity Analyst"].forEach(role => {
      (["warmup", "standard", "stretch"] as const).forEach(difficulty => {
        const pool = getQuestionPool(role, difficulty);
        expect(pool).toHaveLength(8);
        expect(new Set(pool.map(item => item.question)).size).toBe(8);
      });
    });
  });

  it("rejects answers that are too short to evaluate", async () => {
    const caller = appRouter.createCaller(context);
    await expect(caller.interview.evaluateAnswer({
      sessionId: null,
      role: "Frontend Engineer",
      interviewType: "technical",
      question: "Tell me about a frontend performance problem you diagnosed.",
      answer: "brief",
    })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
