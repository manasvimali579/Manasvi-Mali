import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, InterviewAnswer, interviewAnswers, interviewSessions, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      const normalized = user[field] ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createInterviewSession(input: {
  userId?: number;
  role: string;
  interviewType: "technical" | "behavioral" | "mixed";
  difficulty: "warmup" | "standard" | "stretch";
}) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(interviewSessions).values({
    userId: input.userId,
    role: input.role,
    interviewType: input.interviewType,
    difficulty: input.difficulty,
    questionCount: 1,
  });
  return Number(result[0].insertId);
}

export async function saveInterviewAnswer(input: Omit<InterviewAnswer, "id" | "createdAt">) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(interviewAnswers).values(input);
  return Number(result[0].insertId);
}

export async function getInterviewProgress(userId?: number) {
  const empty = { completedSessions: 0, averageScore: null as number | null, streak: 0, focusArea: null as string | null, scoreHistory: [] as number[], recentSessions: [] as Array<{ role: string; type: string; score: number; date: string; accent: string }> };
  if (!userId) return empty;
  const db = await getDb();
  if (!db) return empty;
  const answers = await db.select({
    role: interviewSessions.role,
    type: interviewSessions.interviewType,
    score: interviewAnswers.overall,
    clarity: interviewAnswers.clarity,
    relevance: interviewAnswers.relevance,
    confidence: interviewAnswers.confidence,
    technicalAccuracy: interviewAnswers.technicalAccuracy,
    createdAt: interviewAnswers.createdAt,
  }).from(interviewAnswers)
    .leftJoin(interviewSessions, eq(interviewAnswers.sessionId, interviewSessions.id))
    .where(eq(interviewAnswers.userId, userId))
    .orderBy(desc(interviewAnswers.createdAt));
  if (answers.length === 0) return empty;
  const averageScore = Math.round(answers.reduce((sum, answer) => sum + answer.score, 0) / answers.length);
  const focusScores = {
    Clarity: answers.reduce((sum, answer) => sum + answer.clarity, 0) / answers.length,
    Relevance: answers.reduce((sum, answer) => sum + answer.relevance, 0) / answers.length,
    Confidence: answers.reduce((sum, answer) => sum + answer.confidence, 0) / answers.length,
    "Technical accuracy": answers.reduce((sum, answer) => sum + answer.technicalAccuracy, 0) / answers.length,
  };
  const focusArea = Object.entries(focusScores).sort(([, first], [, second]) => first - second)[0]?.[0] ?? null;
  const dateKeys = new Set(answers.filter(answer => answer.createdAt).map(answer => new Date(answer.createdAt as Date).toISOString().slice(0, 10)));
  const cursor = new Date();
  cursor.setUTCHours(0, 0, 0, 0);
  const todayKey = cursor.toISOString().slice(0, 10);
  if (!dateKeys.has(todayKey)) cursor.setUTCDate(cursor.getUTCDate() - 1);
  let streak = 0;
  while (dateKeys.has(cursor.toISOString().slice(0, 10))) {
    streak += 1;
    cursor.setUTCDate(cursor.getUTCDate() - 1);
  }
  const accentByRole: Record<string, string> = { "Frontend Engineer": "#f59e0b", "Product Designer": "#c084fc", "Data Analyst": "#34d399", "Backend Engineer": "#60a5fa", "Software Engineer": "#818cf8", "ML Engineer": "#22d3ee", "Product Manager": "#fb7185", "DevOps Engineer": "#fb923c", "Cybersecurity Analyst": "#f43f5e" };
  return {
    completedSessions: answers.length,
    averageScore,
    streak,
    focusArea,
    scoreHistory: answers.slice().reverse().map(answer => answer.score),
    recentSessions: answers.map(answer => ({
      role: answer.role ?? "Interview practice",
      type: answer.type ? answer.type[0].toUpperCase() + answer.type.slice(1) : "Mixed",
      score: answer.score,
      date: answer.createdAt ? new Date(answer.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric" }) : "Recently",
      accent: accentByRole[answer.role ?? ""] ?? "#f59e0b",
    })),
  };
}
