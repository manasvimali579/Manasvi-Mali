import { z } from "zod";
import { invokeLLM } from "../_core/llm";
import { createInterviewSession, saveInterviewAnswer } from "../db";
import { publicProcedure, router } from "../_core/trpc";
import { getQuestionPool } from "@shared/questionBank";

const questionSchema = {
  type: "object",
  properties: {
    question: { type: "string" },
    intent: { type: "string" },
    category: { type: "string" },
    tip: { type: "string" },
  },
  required: ["question", "intent", "category", "tip"],
  additionalProperties: false,
} as const;

const evaluationSchema = {
  type: "object",
  properties: {
    clarity: { type: "integer", minimum: 0, maximum: 100 },
    relevance: { type: "integer", minimum: 0, maximum: 100 },
    confidence: { type: "integer", minimum: 0, maximum: 100 },
    technicalAccuracy: { type: "integer", minimum: 0, maximum: 100 },
    overall: { type: "integer", minimum: 0, maximum: 100 },
    feedback: { type: "string" },
    strengths: { type: "array", items: { type: "string" } },
    improvements: { type: "array", items: { type: "string" } },
    followUp: { type: "string" },
  },
  required: ["clarity", "relevance", "confidence", "technicalAccuracy", "overall", "feedback", "strengths", "improvements", "followUp"],
  additionalProperties: false,
} as const;

const fallbackQuestions: Record<string, { question: string; intent: string; category: string; tip: string }> = {
  "Frontend Engineer": {
    question: "Tell me about a frontend performance problem you diagnosed and how you fixed it.",
    intent: "Looks for a structured debugging story and measurable impact.",
    category: "Technical",
    tip: "Use a quick Situation → Diagnosis → Fix → Result arc.",
  },
  "Product Designer": {
    question: "Walk me through a design decision where user research changed your original direction.",
    intent: "Looks for curiosity, tradeoffs, and evidence-led thinking.",
    category: "Behavioral",
    tip: "Name the insight, the pivot, and what improved after launch.",
  },
  "Data Analyst": {
    question: "How would you investigate a sudden 20% drop in weekly active users?",
    intent: "Looks for hypothesis-driven analysis and communication.",
    category: "Technical",
    tip: "Start with data validation, then segment the problem before proposing causes.",
  },
  "Product Manager": {
    question: "Tell me about a time you had to say no to a high-priority stakeholder.",
    intent: "Looks for prioritization, empathy, and clear decision-making.",
    category: "Behavioral",
    tip: "Explain the criteria you used, not just the outcome.",
  },
};

export function fallbackForRole(role: string, previousQuestions: string[] = [], shuffleSeed = Math.random()) {
  const base = fallbackQuestions[role] ?? {
    question: `What is the most important problem you would solve first as a ${role}, and how would you measure success?`,
    intent: "Looks for prioritization, reasoning, and outcome orientation.",
    category: "Behavioral",
    tip: "Be specific about the user, the tradeoff, and the metric.",
  };
  const normalized = new Set(previousQuestions.map(question => question.trim().toLowerCase()));
  const candidates = [
    base,
    {
      question: `How would you approach a high-impact challenge as a ${role}, and how would you measure success?`,
      intent: "Looks for structured thinking, tradeoffs, and measurable outcomes.",
      category: "Behavioral",
      tip: "Name the first step, the tradeoff, and the metric you would watch.",
    },
    {
      question: `Tell me about a difficult ${role} problem you solved and the tradeoffs behind your solution.`,
      intent: "Looks for ownership, judgment, and clear decision-making.",
      category: "Behavioral",
      tip: "Explain the context, options considered, decision, and result.",
    },
    {
      question: `What would you investigate first if a key metric suddenly moved in the wrong direction as a ${role}?`,
      intent: "Looks for a structured diagnostic approach and prioritization.",
      category: "Technical",
      tip: "Start with validation, isolate the change, and name the next action.",
    },
  ];
  const unused = candidates.filter(candidate => !normalized.has(candidate.question.toLowerCase()));
  const pool = unused.length ? unused : candidates;
  return pool[Math.floor(Math.abs(shuffleSeed) * 100000) % pool.length] ?? base;
}

function parseLLMJson(content: unknown) {
  if (typeof content !== "string") return null;
  try {
    return JSON.parse(content);
  } catch {
    return null;
  }
}

export const interviewRouter = router({
  generateQuestion: publicProcedure
    .input(z.object({ role: z.string().min(2), interviewType: z.enum(["technical", "behavioral", "mixed"]), difficulty: z.enum(["warmup", "standard", "stretch"]), sessionId: z.number().nullable().optional(), previousQuestions: z.array(z.string()).max(20).optional(), shuffleSeed: z.number().optional() }))
    .mutation(async ({ input, ctx }) => {
      const previousQuestions = input.previousQuestions ?? [];
      const fallback = fallbackForRole(input.role, previousQuestions, input.shuffleSeed);
      const pool = getQuestionPool(input.role, input.difficulty);
      const excluded = new Set(previousQuestions.map(question => question.trim().toLowerCase()));
      const available = pool.filter(candidate => !excluded.has(candidate.question.trim().toLowerCase()));
      const source = available.length ? available : pool;
      const index = Math.floor(Math.abs(input.shuffleSeed ?? Math.random()) * 100000) % source.length;
      const generated = source[index] ?? fallback;
      const activeSessionId = input.sessionId ?? await createInterviewSession({ userId: ctx.user?.id, role: input.role, interviewType: input.interviewType, difficulty: input.difficulty });
      return { ...generated, sessionId: activeSessionId, source: "pool" as const };
    }),

  evaluateAnswer: publicProcedure
    .input(z.object({ sessionId: z.number().nullable().optional(), role: z.string(), interviewType: z.enum(["technical", "behavioral", "mixed"]), question: z.string(), answer: z.string().min(8) }))
    .mutation(async ({ input, ctx }) => {
      const safeFallback = {
        clarity: Math.min(92, 56 + Math.round(input.answer.length / 12)),
        relevance: Math.min(90, 54 + Math.round(input.answer.length / 14)),
        confidence: 68,
        technicalAccuracy: input.interviewType === "behavioral" ? 74 : 64,
        overall: Math.min(88, 58 + Math.round(input.answer.length / 13)),
        feedback: "You made a clear start and gave the interviewer something concrete to work with. Tighten the answer around one example and land the result with a measurable outcome.",
        strengths: ["You answered directly", "You included useful context", "Your tone feels coachable"],
        improvements: ["Add one measurable result", "Trim setup to make room for the decision", "End with what you learned"],
        followUp: "What tradeoff did you have to make, and how did you decide it was worth it?",
      };
      let evaluation = safeFallback;
      try {
        const response = await invokeLLM({
          model: "gpt-5-mini",
          messages: [
            { role: "system", content: "You are an expert interview coach. Evaluate the answer fairly and constructively. Score each dimension from 0 to 100. Return only JSON matching the schema. Keep feedback concise and specific. For technical accuracy, judge the reasoning shown in the response, not hidden knowledge." },
            { role: "user", content: `Role: ${input.role}\nInterview type: ${input.interviewType}\nQuestion: ${input.question}\nCandidate answer: ${input.answer}` },
          ],
          reasoning: { effort: "minimal" },
          response_format: { type: "json_schema", json_schema: { name: "interview_evaluation", strict: true, schema: evaluationSchema } },
        });
        evaluation = parseLLMJson(response.choices?.[0]?.message?.content) ?? safeFallback;
      } catch (error) {
        console.warn("[Interview] Evaluation fallback:", error);
      }
      const answerId = await saveInterviewAnswer({
        sessionId: input.sessionId ?? null,
        userId: ctx.user?.id ?? null,
        question: input.question,
        answer: input.answer,
        clarity: evaluation.clarity,
        relevance: evaluation.relevance,
        confidence: evaluation.confidence,
        technicalAccuracy: evaluation.technicalAccuracy,
        overall: evaluation.overall,
        feedback: evaluation.feedback,
        strengths: JSON.stringify(evaluation.strengths),
        improvements: JSON.stringify(evaluation.improvements),
        followUp: evaluation.followUp,
      });
      return { ...evaluation, answerId, source: evaluation === safeFallback ? "fallback" : "ai" };
    }),
});
