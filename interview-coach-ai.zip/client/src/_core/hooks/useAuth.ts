import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { LOCAL_DEMO_MODE, DemoUser, getDemoUser, loginLocalAccount, registerLocalAccount, setDemoUser } from "@/lib/localDemo";
import { TRPCClientError } from "@trpc/client";
import { useCallback, useEffect, useMemo, useState } from "react";

type UseAuthOptions = { redirectOnUnauthenticated?: boolean; redirectPath?: string };

export function useAuth(options?: UseAuthOptions) {
  const { redirectOnUnauthenticated = false, redirectPath } = options ?? {};
  const utils = trpc.useUtils();
  const [localUser, setLocalUser] = useState<DemoUser | null>(() => LOCAL_DEMO_MODE ? getDemoUser() : null);
  const [localAuthError, setLocalAuthError] = useState<string | null>(null);
  const meQuery = trpc.auth.me.useQuery(undefined, { retry: false, refetchOnWindowFocus: false, enabled: !LOCAL_DEMO_MODE });
  const logoutMutation = trpc.auth.logout.useMutation({ onSuccess: () => utils.auth.me.setData(undefined, null) });

  useEffect(() => {
    if (!LOCAL_DEMO_MODE) return;
    const sync = () => setLocalUser(getDemoUser());
    window.addEventListener("local-demo-auth", sync);
    return () => window.removeEventListener("local-demo-auth", sync);
  }, []);

  const loginLocal = useCallback(async (email: string, password: string) => {
    try {
      const user = await loginLocalAccount(email, password);
      setLocalUser(user);
      setLocalAuthError(null);
      return user;
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unable to sign in.";
      setLocalAuthError(message);
      throw error;
    }
  }, []);

  const registerLocal = useCallback(async (name: string, email: string, password: string) => {
    try {
      const user = await registerLocalAccount(name, email, password);
      setLocalUser(user);
      setLocalAuthError(null);
      return user;
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unable to create your account.";
      setLocalAuthError(message);
      throw error;
    }
  }, []);

  const logout = useCallback(async () => {
    if (LOCAL_DEMO_MODE) {
      setDemoUser(null);
      setLocalUser(null);
      return;
    }
    try {
      await logoutMutation.mutateAsync();
    } catch (error: unknown) {
      if (!(error instanceof TRPCClientError && error.data?.code === "UNAUTHORIZED")) throw error;
    } finally {
      try { sessionStorage.removeItem("manus-cookie"); } catch {}
      utils.auth.me.setData(undefined, null);
      await utils.auth.me.invalidate();
    }
  }, [logoutMutation, utils]);

  const state = useMemo(() => {
    const currentUser = LOCAL_DEMO_MODE ? localUser : (meQuery.data ?? null);
    try { localStorage.setItem("manus-runtime-user-info", JSON.stringify(currentUser)); } catch {}
    return {
      user: currentUser,
      loading: LOCAL_DEMO_MODE ? false : meQuery.isLoading || logoutMutation.isPending,
      error: LOCAL_DEMO_MODE ? localAuthError : meQuery.error ?? logoutMutation.error ?? null,
      isAuthenticated: Boolean(currentUser),
    };
  }, [localAuthError, localUser, meQuery.data, meQuery.error, meQuery.isLoading, logoutMutation.error, logoutMutation.isPending]);

  useEffect(() => {
    if (LOCAL_DEMO_MODE || !redirectOnUnauthenticated || meQuery.isLoading || logoutMutation.isPending || state.user) return;
    if (redirectPath && window.location.pathname === redirectPath) return;
    if (redirectPath) window.location.href = redirectPath;
    else startLogin();
  }, [redirectOnUnauthenticated, redirectPath, logoutMutation.isPending, meQuery.isLoading, state.user]);

  return { ...state, refresh: () => meQuery.refetch(), logout, loginLocal, registerLocal };
}
