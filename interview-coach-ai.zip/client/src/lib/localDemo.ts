export const LOCAL_DEMO_MODE = !import.meta.env.VITE_APP_ID;

export type DemoUser = {
  id: number;
  openId: string;
  name: string;
  email: string;
  role: "user";
};

export type LocalEvaluation = {
  clarity: number;
  relevance: number;
  confidence: number;
  technicalAccuracy: number;
  overall: number;
  feedback: string;
  strengths: string[];
  improvements: string[];
  followUp: string;
  role: string;
  type: string;
  createdAt: string;
};

const USER_KEY = "interview-coach-local-user";
const ACCOUNTS_KEY = "interview-coach-local-accounts";
const PROGRESS_KEY = "interview-coach-demo-progress";

type LocalAccount = DemoUser & { passwordHash: string };

function getAccounts(): LocalAccount[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(ACCOUNTS_KEY);
    return raw ? JSON.parse(raw) as LocalAccount[] : [];
  } catch {
    return [];
  }
}

function saveAccounts(accounts: LocalAccount[]) {
  window.localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
}

async function hashPassword(password: string) {
  const bytes = new TextEncoder().encode(password);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest)).map(byte => byte.toString(16).padStart(2, "0")).join("");
}

export async function registerLocalAccount(name: string, email: string, password: string) {
  const normalizedEmail = email.trim().toLowerCase();
  if (name.trim().length < 2) throw new Error("Enter your name.");
  if (!normalizedEmail.includes("@")) throw new Error("Enter a valid email address.");
  if (password.length < 6) throw new Error("Password must be at least 6 characters.");
  const accounts = getAccounts();
  if (accounts.some(account => account.email === normalizedEmail)) throw new Error("An account with this email already exists.");
  const user: DemoUser = { id: Date.now(), openId: `local-${Date.now()}`, name: name.trim(), email: normalizedEmail, role: "user" };
  accounts.push({ ...user, passwordHash: await hashPassword(password) });
  saveAccounts(accounts);
  setDemoUser(user);
  return user;
}

export async function loginLocalAccount(email: string, password: string) {
  const normalizedEmail = email.trim().toLowerCase();
  const account = getAccounts().find(candidate => candidate.email === normalizedEmail);
  if (!account || account.passwordHash !== await hashPassword(password)) throw new Error("Email or password is incorrect.");
  const { passwordHash: _passwordHash, ...user } = account;
  setDemoUser(user);
  return user;
}

export function getDemoUser(): DemoUser | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(USER_KEY);
    return raw ? JSON.parse(raw) as DemoUser : null;
  } catch {
    return null;
  }
}

export function setDemoUser(user: DemoUser | null) {
  if (typeof window === "undefined") return;
  if (user) window.localStorage.setItem(USER_KEY, JSON.stringify(user));
  else window.localStorage.removeItem(USER_KEY);
  window.dispatchEvent(new Event("local-demo-auth"));
}

function userProgressKey(user: DemoUser) {
  return `${PROGRESS_KEY}:${user.openId}`;
}

function localDateKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

export function getLocalEvaluations(user: DemoUser | null): LocalEvaluation[] {
  if (!user || typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(userProgressKey(user));
    return raw ? JSON.parse(raw) as LocalEvaluation[] : [];
  } catch {
    return [];
  }
}

export function saveLocalEvaluation(user: DemoUser | null, evaluation: Omit<LocalEvaluation, "createdAt">) {
  if (!user || typeof window === "undefined") return;
  const evaluations = getLocalEvaluations(user);
  evaluations.push({ ...evaluation, createdAt: new Date().toISOString() });
  window.localStorage.setItem(userProgressKey(user), JSON.stringify(evaluations));
  window.dispatchEvent(new Event("local-demo-progress"));
}

export function makeOfflineEvaluation(answer: string, interviewType: string): Omit<LocalEvaluation, "createdAt" | "role" | "type"> {
  const lengthBonus = Math.min(22, Math.floor(answer.trim().length / 18));
  const technicalAccuracy = interviewType === "behavioral" ? 74 : 62 + lengthBonus;
  const overall = Math.min(90, 60 + lengthBonus);
  return {
    clarity: Math.min(92, 64 + lengthBonus),
    relevance: Math.min(90, 62 + lengthBonus),
    confidence: Math.min(88, 66 + Math.floor(lengthBonus / 2)),
    technicalAccuracy,
    overall,
    feedback: "Your answer gives the coach a useful starting point. Add one specific example, explain your decision, and finish with the result.",
    strengths: ["You answered directly", "You provided useful context", "Your response shows coachability"],
    improvements: ["Add one measurable result", "Use a clear Situation → Action → Result structure", "End with what you learned"],
    followUp: "What would you do differently if you had more time or information?",
  };
}

export function buildLocalProgress(user: DemoUser | null) {
  const evaluations = getLocalEvaluations(user);
  if (!evaluations.length) return { completedSessions: 0, averageScore: null as number | null, streak: 0, focusArea: null as string | null, scoreHistory: [] as number[], recentSessions: [] as Array<{ role: string; type: string; score: number; date: string; accent: string }> };
  const averageScore = Math.round(evaluations.reduce((sum, item) => sum + item.overall, 0) / evaluations.length);
  const categoryScores = {
    Clarity: evaluations.reduce((sum, item) => sum + item.clarity, 0) / evaluations.length,
    Relevance: evaluations.reduce((sum, item) => sum + item.relevance, 0) / evaluations.length,
    Confidence: evaluations.reduce((sum, item) => sum + item.confidence, 0) / evaluations.length,
    "Technical accuracy": evaluations.reduce((sum, item) => sum + item.technicalAccuracy, 0) / evaluations.length,
  };
  const focusArea = Object.entries(categoryScores).sort(([, first], [, second]) => first - second)[0]?.[0] ?? null;
  const dates = new Set(evaluations.map(item => localDateKey(new Date(item.createdAt))));
  const cursor = new Date();
  cursor.setHours(0, 0, 0, 0);
  if (!dates.has(localDateKey(cursor))) cursor.setDate(cursor.getDate() - 1);
  let streak = 0;
  while (dates.has(localDateKey(cursor))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  const accentByRole: Record<string, string> = { "Frontend Engineer": "#f59e0b", "Product Designer": "#c084fc", "Data Analyst": "#34d399", "Backend Engineer": "#60a5fa", "Software Engineer": "#818cf8", "ML Engineer": "#22d3ee", "Product Manager": "#fb7185", "DevOps Engineer": "#fb923c", "Cybersecurity Analyst": "#f43f5e" };
  return {
    completedSessions: evaluations.length,
    averageScore,
    streak,
    focusArea,
    scoreHistory: evaluations.map(item => item.overall),
    recentSessions: evaluations.slice().reverse().map(item => ({ role: item.role, type: item.type[0].toUpperCase() + item.type.slice(1), score: item.overall, date: new Date(item.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric" }), accent: accentByRole[item.role] ?? "#f59e0b" })),
  };
}

export function notifyDemoProgress() {
  if (typeof window !== "undefined") window.dispatchEvent(new Event("local-demo-progress"));
}
