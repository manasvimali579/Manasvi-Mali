import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  ArrowUpRight,
  BarChart3,
  BrainCircuit,
  Check,
  ChevronRight,
  Clock3,
  Flame,
  LayoutDashboard,
  Mic,
  Mic2,
  MoreHorizontal,
  Play,
  RefreshCw,
  Sparkles,
  Target,
  TrendingUp,
  Trophy,
  UserRound,
  Volume2,
  X,
  Zap,
} from "lucide-react";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { LOCAL_DEMO_MODE, buildLocalProgress, makeOfflineEvaluation, saveLocalEvaluation } from "@/lib/localDemo";
import { getQuestionPool } from "@shared/questionBank";

const roles = [
  { name: "Frontend Engineer", short: "FE", accent: "#f59e0b", questions: 18, description: "UI systems, performance, and craft" },
  { name: "Backend Engineer", short: "BE", accent: "#60a5fa", questions: 20, description: "APIs, systems, and reliability" },
  { name: "Software Engineer", short: "SWE", accent: "#818cf8", questions: 24, description: "Algorithms, design, and delivery" },
  { name: "Product Designer", short: "PD", accent: "#c084fc", questions: 12, description: "Research, systems, and storytelling" },
  { name: "Data Analyst", short: "DA", accent: "#34d399", questions: 9, description: "Metrics, SQL, and decisions" },
  { name: "ML Engineer", short: "ML", accent: "#22d3ee", questions: 15, description: "Models, evaluation, and scale" },
  { name: "Product Manager", short: "PM", accent: "#fb7185", questions: 16, description: "Strategy, tradeoffs, and influence" },
  { name: "DevOps Engineer", short: "DO", accent: "#fb923c", questions: 14, description: "Cloud, CI/CD, and observability" },
  { name: "Cybersecurity Analyst", short: "SEC", accent: "#f43f5e", questions: 11, description: "Threats, controls, and response" },
];

const sessions = [
  { role: "Frontend Engineer", type: "Technical", score: 86, date: "Today", accent: "#f59e0b" },
  { role: "Product Designer", type: "Behavioral", score: 78, date: "Yesterday", accent: "#c084fc" },
  { role: "Frontend Engineer", type: "Mixed", score: 81, date: "Sep 16", accent: "#f59e0b" },
];

const scoreBars = [58, 64, 62, 71, 68, 79, 76, 86, 81, 88, 84, 91];

const starterQuestion = {
  question: "Tell me about a frontend performance problem you diagnosed and how you fixed it.",
  intent: "Looks for a structured debugging story and measurable impact.",
  category: "Technical",
  tip: "Use a quick Situation → Diagnosis → Fix → Result arc.",
};

type Evaluation = {
  clarity: number;
  relevance: number;
  confidence: number;
  technicalAccuracy: number;
  overall: number;
  feedback: string;
  strengths: string[];
  improvements: string[];
  followUp: string;
};

type View = "overview" | "practice" | "progress";

function initials(name: string) {
  return name.split(" ").map(part => part[0]).join("").slice(0, 2);
}

function scoreTone(score: number) {
  if (score >= 85) return "text-emerald-300";
  if (score >= 70) return "text-amber-300";
  return "text-rose-300";
}

export default function Home() {
  const { user, isAuthenticated, loading: authLoading, logout, loginLocal, registerLocal, error: authError } = useAuth();
  const [localProgressVersion, setLocalProgressVersion] = useState(0);
  const progressQuery = trpc.progress.useQuery(undefined, { enabled: !LOCAL_DEMO_MODE });
  const trpcUtils = trpc.useUtils();
  useEffect(() => {
    if (!LOCAL_DEMO_MODE) return;
    const refresh = () => setLocalProgressVersion(value => value + 1);
    window.addEventListener("local-demo-progress", refresh);
    return () => window.removeEventListener("local-demo-progress", refresh);
  }, [user]);
  const localProgress = useMemo(() => buildLocalProgress(user as Parameters<typeof buildLocalProgress>[0]), [user, localProgressVersion]);
  const progress = LOCAL_DEMO_MODE ? localProgress : (progressQuery.data ?? { completedSessions: 0, averageScore: null, streak: 0, focusArea: null, scoreHistory: [], recentSessions: [] });
  const hasProgress = progress.completedSessions > 0;
  const chartBars = progress.scoreHistory;
  const streakDots = Array.from({ length: 7 }, (_, index) => index < Math.min(progress.streak, 7));
  const [view, setView] = useState<View>("overview");
  const [selectedRole, setSelectedRole] = useState(roles[0].name);
  const [interviewType, setInterviewType] = useState<"technical" | "behavioral" | "mixed">("mixed");
  const [difficulty, setDifficulty] = useState<"warmup" | "standard" | "stretch">("standard");
  const [totalQuestions, setTotalQuestions] = useState(5);
  const [questionNumber, setQuestionNumber] = useState(1);
  const [questionHistory, setQuestionHistory] = useState<string[]>([]);
  const [question, setQuestion] = useState(starterQuestion);
  const [sessionId, setSessionId] = useState<number | null>(null);
  const [answer, setAnswer] = useState("");
  const [evaluation, setEvaluation] = useState<Evaluation | null>(null);
  const [seconds, setSeconds] = useState(88);
  const [timerRunning, setTimerRunning] = useState(true);
  const [isListening, setIsListening] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState("");
  const [showSetup, setShowSetup] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState<"signin" | "register">("signin");
  const [authName, setAuthName] = useState("");
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authSubmitting, setAuthSubmitting] = useState(false);
  const [notice, setNotice] = useState("");
  const [now, setNow] = useState(() => new Date());

  const generateQuestion = trpc.interview.generateQuestion.useMutation();
  const evaluateAnswer = trpc.interview.evaluateAnswer.useMutation();

  useEffect(() => {
    if (view !== "practice" || !timerRunning || evaluation) return;
    const timer = window.setInterval(() => setSeconds(value => value > 0 ? value - 1 : 0), 1000);
    return () => window.clearInterval(timer);
  }, [view, timerRunning, evaluation]);

  useEffect(() => {
    const clock = window.setInterval(() => setNow(new Date()), 60_000);
    return () => window.clearInterval(clock);
  }, []);

  const currentRole = useMemo(() => roles.find(role => role.name === selectedRole) ?? roles[0], [selectedRole]);
  const displayName = user?.name?.trim() || "there";
  const displayFirstName = displayName.split(" ")[0];
  const userInitials = user?.name ? initials(user.name) : "?";
  const greeting = now.getHours() < 12 ? "Good morning" : now.getHours() < 18 ? "Good afternoon" : "Good evening";
  const todayLabel = now.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" });
  const minutes = Math.floor(seconds / 60).toString().padStart(2, "0");
  const secs = (seconds % 60).toString().padStart(2, "0");

  const submitAuth = async (event: FormEvent) => {
    event.preventDefault();
    setAuthSubmitting(true);
    try {
      if (authMode === "register") await registerLocal(authName, authEmail, authPassword);
      else await loginLocal(authEmail, authPassword);
      setShowAuth(false);
      setAuthName("");
      setAuthEmail("");
      setAuthPassword("");
    } catch {
      // The auth hook exposes the validation message in the form below.
    } finally {
      setAuthSubmitting(false);
    }
  };

  const startPractice = async () => {
    setNotice("");
    setEvaluation(null);
    setAnswer("");
    setSeconds(88);
    setQuestionNumber(1);
    setQuestionHistory([]);
    setTimerRunning(true);
    setShowSetup(false);
    setView("practice");
    try {
      const result = await generateQuestion.mutateAsync({ role: selectedRole, interviewType, difficulty, sessionId: null, previousQuestions: [], shuffleSeed: Math.random() });
      setQuestion(result);
      setSessionId(result.sessionId ?? null);
      setQuestionHistory([result.question]);
    } catch {
      const pool = getQuestionPool(selectedRole, difficulty);
      const localQuestion = pool[Math.floor(Math.random() * pool.length)] ?? starterQuestion;
      setQuestion(localQuestion);
      setQuestionHistory([localQuestion.question]);
      setNotice("Local demo mode: questions are loaded from the built-in practice bank.");
    }
  };

  const submitAnswer = async () => {
    if (answer.trim().length < 8) {
      setNotice("Add a little more detail so your coach can give you useful feedback.");
      return;
    }
    setNotice("");
    setTimerRunning(false);
    try {
      if (LOCAL_DEMO_MODE) {
        const offline = makeOfflineEvaluation(answer, interviewType);
        const localResult = { ...offline, role: selectedRole, type: interviewType };
        saveLocalEvaluation(user as Parameters<typeof saveLocalEvaluation>[0], localResult);
        setEvaluation(localResult);
        setLocalProgressVersion(value => value + 1);
        return;
      }
      const result = await evaluateAnswer.mutateAsync({
        sessionId,
        role: selectedRole,
        interviewType,
        question: question.question,
        answer,
      });
      setEvaluation(result);
      void trpcUtils.progress.invalidate();
    } catch {
      const offline = makeOfflineEvaluation(answer, interviewType);
      const localResult = { ...offline, role: selectedRole, type: interviewType };
      saveLocalEvaluation(user as Parameters<typeof saveLocalEvaluation>[0], localResult);
      setEvaluation(localResult);
      setLocalProgressVersion(value => value + 1);
      setNotice("Offline demo feedback generated locally. Your progress was saved in this browser.");
    }
  };

  const nextQuestion = async () => {
    if (questionNumber >= totalQuestions) {
      setView("overview");
      setNotice(`Session complete — you finished ${totalQuestions} questions for ${selectedRole}.`);
      return;
    }
    setEvaluation(null);
    setAnswer("");
    setSeconds(88);
    setQuestionNumber(value => value + 1);
    setTimerRunning(true);
    const previousQuestions = questionHistory.includes(question.question) ? questionHistory : [...questionHistory, question.question];
    try {
      const result = await generateQuestion.mutateAsync({ role: selectedRole, interviewType, difficulty, sessionId, previousQuestions, shuffleSeed: Math.random() });
      setQuestion(result);
      setSessionId(result.sessionId ?? sessionId);
      setQuestionHistory(history => [...history, result.question].slice(-20));
    } catch {
      const pool = getQuestionPool(selectedRole, difficulty).filter(item => !previousQuestions.includes(item.question));
      const localQuestion = pool[Math.floor(Math.random() * pool.length)] ?? getQuestionPool(selectedRole, difficulty)[0] ?? starterQuestion;
      setQuestion(localQuestion);
      setQuestionHistory(history => [...history, localQuestion.question].slice(-20));
      setNotice("Next question loaded from the local practice bank.");
    }
  };

  const toggleVoice = () => {
    const SpeechRecognition = (window as Window & { webkitSpeechRecognition?: new () => any; SpeechRecognition?: new () => any }).SpeechRecognition
      ?? (window as Window & { webkitSpeechRecognition?: new () => any }).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setNotice("Voice capture isn’t supported in this browser. You can still type your answer.");
      return;
    }
    if (isListening) return;
    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.interimResults = true;
    recognition.continuous = false;
    recognition.onstart = () => setIsListening(true);
    recognition.onresult = (event: any) => {
      let transcript = "";
      for (let index = event.resultIndex; index < event.results.length; index += 1) transcript += event.results[index][0].transcript;
      setLiveTranscript(transcript);
      if (event.results[event.results.length - 1].isFinal) setAnswer(value => `${value}${value ? " " : ""}${transcript}`);
    };
    recognition.onerror = () => setNotice("I couldn’t hear that clearly — try again or type your response.");
    recognition.onend = () => {
      setIsListening(false);
      setLiveTranscript("");
    };
    recognition.start();
  };

  if (view === "practice") {
    return (
      <div className="min-h-screen bg-[#111827] text-white">
        <header className="mx-auto flex max-w-[1440px] items-center justify-between px-6 py-5 lg:px-10">
          <button onClick={() => setView("overview")} className="group flex items-center gap-3 text-left">
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-amber-300 text-[#111827] shadow-[0_0_0_5px_rgba(251,191,36,0.12)]"><Sparkles size={17} strokeWidth={2.5} /></div>
            <div><p className="font-display text-[15px] font-bold tracking-tight">Interview Coach</p><p className="text-[10px] uppercase tracking-[0.2em] text-slate-400">Practice studio</p></div>
          </button>
          <div className="flex items-center gap-3"><div className="hidden rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs text-slate-300 sm:block"><span className="mr-2 inline-block h-2 w-2 rounded-full bg-emerald-400" />AI coach online</div><button onClick={() => setView("overview")} className="rounded-full border border-white/10 px-3 py-2 text-sm text-slate-300 transition hover:bg-white/10">Exit practice</button></div>
        </header>
        <main className="mx-auto max-w-[1180px] px-6 pb-12 pt-8 lg:px-10">
          <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
            <div><div className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-amber-300"><span className="h-1.5 w-1.5 rounded-full bg-amber-300" />Live practice</div><h1 className="font-display max-w-2xl text-3xl font-semibold tracking-tight sm:text-4xl">Let’s make your next answer <span className="text-amber-300">land.</span></h1><p className="mt-3 text-sm text-slate-400">{selectedRole} · {interviewType[0].toUpperCase() + interviewType.slice(1)} interview · {difficulty} pace</p></div>
            <div className="flex items-center gap-3"><div className={`rounded-2xl border px-4 py-3 ${seconds < 20 ? "border-rose-400/40 bg-rose-400/10" : "border-white/10 bg-white/5"}`}><p className="mb-1 text-[10px] uppercase tracking-[0.16em] text-slate-500">Time left</p><p className="font-display text-xl font-semibold tabular-nums">{minutes}:{secs}</p></div><button onClick={() => setTimerRunning(value => !value)} className="grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-white/5 text-slate-300 transition hover:border-amber-300/50 hover:text-amber-300" title="Pause timer">{timerRunning ? <span className="text-xs font-bold">Ⅱ</span> : <Play size={16} fill="currentColor" />}</button></div>
          </div>
          <div className="grid gap-6 lg:grid-cols-[1.08fr_0.92fr]">
            <section className="relative overflow-hidden rounded-[28px] border border-white/10 bg-[#1a2536] p-7 shadow-2xl shadow-black/20 sm:p-9">
              <div className="absolute right-0 top-0 h-44 w-44 rounded-full bg-amber-300/10 blur-3xl" />
              <div className="relative flex items-start justify-between gap-4"><div><div className="flex flex-wrap items-center gap-3"><p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-amber-300">Question {String(questionNumber).padStart(2, "0")} <span className="text-slate-500">/ {String(totalQuestions).padStart(2, "0")}</span></p><div className="flex gap-1">{Array.from({ length: totalQuestions }).map((_, index) => <span key={index} className={`h-1 w-5 rounded-full ${index < questionNumber ? "bg-amber-300" : "bg-white/10"}`} />)}</div></div><h2 className="mt-5 max-w-2xl font-display text-2xl font-semibold leading-tight sm:text-[30px]">{question.question}</h2></div><div className="hidden h-10 w-10 shrink-0 place-items-center rounded-full bg-white/5 text-slate-400 sm:grid"><MoreHorizontal size={18} /></div></div>
              <div className="mt-7 grid gap-3 border-t border-white/10 pt-5 sm:grid-cols-2"><div><p className="mb-1 text-[10px] uppercase tracking-[0.16em] text-slate-500">What I’m listening for</p><p className="text-sm leading-relaxed text-slate-300">{question.intent}</p></div><div><p className="mb-1 text-[10px] uppercase tracking-[0.16em] text-slate-500">Coach cue</p><p className="text-sm leading-relaxed text-slate-300">{question.tip}</p></div></div>
              <div className="mt-7 rounded-2xl border border-white/10 bg-[#111827]/70 p-4"><div className="mb-3 flex items-center justify-between"><label htmlFor="answer" className="text-xs font-semibold text-slate-300">Your answer</label><span className="text-[11px] text-slate-500">{answer.length} chars</span></div><textarea id="answer" value={answer} onChange={event => setAnswer(event.target.value)} placeholder="Take a breath, then talk me through it…" className="min-h-[150px] w-full resize-none bg-transparent text-[15px] leading-7 text-white outline-none placeholder:text-slate-600" /><div className="mt-3 flex items-center justify-between gap-3 border-t border-white/10 pt-3"><button onClick={toggleVoice} className={`flex items-center gap-2 rounded-full px-3 py-2 text-xs font-semibold transition ${isListening ? "bg-rose-400/15 text-rose-300" : "text-slate-400 hover:bg-white/5 hover:text-white"}`}><Mic2 size={15} />{isListening ? "Listening…" : "Answer with voice"}</button><span className="hidden text-xs text-slate-600 sm:block">Aim for 60–90 seconds</span></div>{liveTranscript && <p className="mt-2 text-xs text-amber-200/80">{liveTranscript}</p>}</div>
              {notice && <div className="mt-4 flex items-center gap-2 rounded-xl border border-amber-300/20 bg-amber-300/10 px-3 py-2 text-xs text-amber-100"><Zap size={14} />{notice}</div>}
              <div className="mt-5 flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between"><button onClick={() => setView("overview")} className="text-sm font-medium text-slate-400 transition hover:text-white">Save & exit</button><button onClick={submitAnswer} disabled={evaluateAnswer.isPending} className="inline-flex items-center justify-center gap-2 rounded-full bg-amber-300 px-5 py-3 text-sm font-bold text-[#111827] transition hover:bg-amber-200 disabled:cursor-wait disabled:opacity-70">{evaluateAnswer.isPending ? <RefreshCw size={16} className="animate-spin" /> : <Sparkles size={16} />}Get coach feedback <ArrowUpRight size={16} /></button></div>
            </section>
            <aside className="rounded-[28px] border border-white/10 bg-[#172132] p-6 sm:p-7"><div className="flex items-center justify-between"><div><p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-500">Coach workspace</p><h3 className="mt-2 font-display text-xl font-semibold">{evaluation ? "A sharper version" : "Stay in your flow"}</h3></div><div className="grid h-11 w-11 place-items-center rounded-2xl bg-amber-300/10 text-amber-300"><BrainCircuit size={21} /></div></div>{evaluation ? <div className="mt-7 space-y-5"><div className="flex items-end gap-3"><span className={`font-display text-6xl font-semibold tracking-tight ${scoreTone(evaluation.overall)}`}>{evaluation.overall}</span><span className="pb-2 text-sm text-slate-500">/ 100 overall</span></div><p className="text-sm leading-6 text-slate-300">{evaluation.feedback}</p><div className="grid grid-cols-2 gap-3">{[["Clarity", evaluation.clarity], ["Relevance", evaluation.relevance], ["Confidence", evaluation.confidence], ["Accuracy", evaluation.technicalAccuracy]].map(([label, score]) => <div key={label as string} className="rounded-2xl border border-white/8 bg-white/[0.03] p-3"><div className="mb-2 flex justify-between text-[11px] text-slate-500"><span>{label as string}</span><span className="font-semibold text-slate-200">{score as number}</span></div><div className="h-1.5 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-amber-300" style={{ width: `${score}%` }} /></div></div>)}</div><div><p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-emerald-300">Keep doing</p><div className="space-y-2">{evaluation.strengths.map(item => <p key={item} className="flex gap-2 text-xs leading-5 text-slate-300"><Check size={14} className="mt-0.5 shrink-0 text-emerald-300" />{item}</p>)}</div></div><div><p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-amber-300">Next reps</p><div className="space-y-2">{evaluation.improvements.map(item => <p key={item} className="flex gap-2 text-xs leading-5 text-slate-300"><Target size={14} className="mt-0.5 shrink-0 text-amber-300" />{item}</p>)}</div></div><div className="rounded-2xl bg-amber-300 p-4 text-[#111827]"><p className="text-[10px] font-bold uppercase tracking-[0.16em] opacity-60">Follow-up question</p><p className="mt-2 text-sm font-semibold leading-5">{evaluation.followUp}</p></div><button onClick={nextQuestion} disabled={generateQuestion.isPending} className="flex w-full items-center justify-center gap-2 rounded-full border border-white/15 py-3 text-sm font-semibold text-white transition hover:bg-white/10 disabled:opacity-60">{generateQuestion.isPending ? <RefreshCw size={15} className="animate-spin" /> : <ChevronRight size={16} />}{questionNumber >= totalQuestions ? "Finish session" : "Next question"}</button></div> : <div className="mt-7 space-y-6"><div className="rounded-2xl border border-amber-300/15 bg-amber-300/[0.07] p-4"><div className="mb-3 flex items-center gap-2 text-amber-200"><Volume2 size={15} /><span className="text-xs font-semibold">A small reminder</span></div><p className="text-sm leading-6 text-slate-300">The goal isn’t to sound perfect. It’s to make your thinking easy to follow.</p></div><div className="space-y-4">{[["1", "Lead with the headline", "Give the answer before the backstory."], ["2", "Name the tradeoff", "Show how you made the call."], ["3", "Land the result", "Close with the measurable change."]].map(([number, title, copy]) => <div key={number} className="flex gap-3"><div className="grid h-7 w-7 shrink-0 place-items-center rounded-full border border-white/10 text-[11px] font-bold text-amber-300">{number}</div><div><p className="text-sm font-semibold text-slate-200">{title}</p><p className="mt-1 text-xs leading-5 text-slate-500">{copy}</p></div></div>)}</div><div className="border-t border-white/10 pt-5"><p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Answer format</p><div className="mt-3 flex flex-wrap gap-2"><span className="rounded-full bg-white/5 px-3 py-1.5 text-xs text-slate-300">Situation</span><span className="text-slate-600">→</span><span className="rounded-full bg-white/5 px-3 py-1.5 text-xs text-slate-300">Action</span><span className="text-slate-600">→</span><span className="rounded-full bg-white/5 px-3 py-1.5 text-xs text-slate-300">Result</span></div></div></div>}</aside>
          </div>
        </main>
      </div>
    );
  }

  if (view === "progress") {
    return (
      <div className="min-h-screen bg-[#f5f2eb] text-[#172132]">
        <header className="flex items-center justify-between border-b border-[#ded9ce] bg-[#f5f2eb] px-5 py-4 sm:px-8 lg:px-12"><button onClick={() => setView("overview")} className="flex items-center gap-2 text-sm font-semibold text-[#5e5b54] transition hover:text-[#172132]"><ChevronRight className="rotate-180" size={16} />Back to overview</button><button onClick={() => { setView("overview"); setShowSetup(true); }} className="rounded-full bg-[#172132] px-4 py-2.5 text-xs font-bold text-white transition hover:bg-[#25354d]"><Play size={13} className="mr-2 inline" fill="currentColor" />Start practice</button></header>
        <main className="mx-auto max-w-[1180px] px-5 py-8 sm:px-8 lg:px-12 lg:py-11"><div><p className="text-[11px] font-bold uppercase tracking-[0.2em] text-[#b47719]">Personal analytics</p><h1 className="mt-3 font-display text-3xl font-semibold sm:text-[40px]">My progress</h1><p className="mt-2 text-sm text-[#77736a]">A clear view of the reps you have actually completed.</p></div><div className="mt-8 grid gap-4 sm:grid-cols-3"><div className="rounded-[22px] border border-[#dfd9cc] bg-[#fffcf6] p-5 shadow-sm"><p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[#8d897f]">Completed answers</p><p className="mt-4 font-display text-4xl font-semibold">{progress.completedSessions}</p><p className="mt-2 text-xs text-[#8d897f]">Saved coaching evaluations</p></div><div className="rounded-[22px] border border-[#dfd9cc] bg-[#fffcf6] p-5 shadow-sm"><p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[#8d897f]">Average readiness</p><p className="mt-4 font-display text-4xl font-semibold">{progress.averageScore ?? "—"}</p><p className="mt-2 text-xs text-[#8d897f]">Across completed answers</p></div><div className="rounded-[22px] border border-[#dfd9cc] bg-[#fffcf6] p-5 shadow-sm"><p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[#8d897f]">Practice streak</p><p className="mt-4 font-display text-4xl font-semibold">{progress.streak}</p><p className="mt-2 text-xs text-[#8d897f]">{progress.streak === 1 ? "consecutive day" : "consecutive days"}</p></div></div><div className="mt-6 grid gap-6 lg:grid-cols-[1.25fr_0.75fr]"><section className="rounded-[26px] border border-[#dfd9cc] bg-[#fffcf6] p-6 shadow-sm sm:p-7"><div className="flex items-center justify-between"><div><p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#8d897f]">Score history</p><h2 className="mt-2 font-display text-xl font-semibold">Your actual answer scores</h2></div><BarChart3 className="text-[#b47719]" size={20} /></div>{progress.scoreHistory.length > 0 ? <div className="mt-8 flex h-[220px] items-end gap-2 sm:gap-3">{progress.scoreHistory.map((score, index) => <div key={`${score}-${index}`} className="flex flex-1 flex-col items-center gap-2"><div className="flex h-[175px] w-full items-end"><div className="w-full rounded-t-md bg-[#172132]" style={{ height: `${score}%` }} /></div><span className="text-[10px] text-[#aaa59a]">{index + 1}</span></div>)}</div> : <div className="mt-8 grid h-[220px] place-items-center rounded-2xl border border-dashed border-[#d8d2c5] text-center"><div><p className="text-sm font-semibold text-[#5e5b54]">No score history yet</p><p className="mt-1 text-xs text-[#8d897f]">Complete your first answer to start tracking progress.</p></div></div>}</section><section className="rounded-[26px] bg-[#172132] p-6 text-white shadow-xl shadow-[#172132]/15 sm:p-7"><div className="grid h-10 w-10 place-items-center rounded-2xl bg-amber-300 text-[#172132]"><Target size={19} /></div><p className="mt-7 text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-500">Current focus area</p><h2 className="mt-3 font-display text-2xl font-semibold text-amber-300">{progress.focusArea ?? "Not set"}</h2><p className="mt-4 text-sm leading-6 text-slate-400">{progress.focusArea ? "This is the lowest average category in your completed evaluations. Practice it deliberately in your next rep." : "Your focus area will appear after you complete an answer."}</p><button onClick={() => { setView("overview"); setShowSetup(true); }} className="mt-7 flex items-center gap-2 text-sm font-bold text-amber-300">Practice this next <ChevronRight size={16} /></button></section></div><section className="mt-6 rounded-[26px] border border-[#dfd9cc] bg-[#fffcf6] p-6 shadow-sm sm:p-7"><p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#8d897f]">Recent activity</p><div className="mt-4 divide-y divide-[#eee9df]">{progress.recentSessions.length > 0 ? progress.recentSessions.map(session => <div key={`${session.role}-${session.date}`} className="flex items-center justify-between gap-4 py-4 first:pt-1"><div><p className="text-sm font-semibold">{session.role}</p><p className="mt-1 text-xs text-[#8d897f]">{session.type} · {session.date}</p></div><p className="font-display text-xl font-semibold text-[#b47719]">{session.score}<span className="ml-1 text-xs font-normal text-[#aaa59a]">/100</span></p></div>) : <p className="mt-4 text-sm text-[#8d897f]">No completed practice sessions yet.</p>}</div></section></main>{showSetup && <div className="fixed inset-0 z-50" />}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f5f2eb] text-[#172132]">
      <aside className="fixed inset-y-0 left-0 hidden w-[245px] flex-col border-r border-[#d9d4c8] bg-[#eeeae1] px-5 py-6 lg:flex"><div className="flex items-center gap-3 px-2"><div className="grid h-9 w-9 place-items-center rounded-xl bg-[#172132] text-amber-300"><Sparkles size={17} strokeWidth={2.5} /></div><div><p className="font-display text-[15px] font-bold tracking-tight">Interview Coach</p><p className="text-[10px] uppercase tracking-[0.2em] text-[#8c887d]">Practice studio</p></div></div><nav className="mt-12 space-y-1"><button onClick={() => setView("overview")} className="flex w-full items-center gap-3 rounded-xl bg-[#172132] px-3 py-3 text-left text-sm font-semibold text-white shadow-sm"><LayoutDashboard size={17} />Overview</button><button onClick={() => setShowSetup(true)} className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-medium text-[#706e66] transition hover:bg-white/60 hover:text-[#172132]"><Play size={17} />Practice</button><button onClick={() => { setShowSetup(false); setView("progress"); }} className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-medium text-[#706e66] transition hover:bg-white/60 hover:text-[#172132]"><BarChart3 size={17} />My progress</button></nav><div className="mt-auto rounded-2xl bg-[#172132] p-4 text-white"><div className="mb-3 flex items-center justify-between"><span className="text-[10px] uppercase tracking-[0.16em] text-slate-400">Weekly goal</span><Flame size={16} className="text-amber-300" /></div><p className="font-display text-2xl font-semibold">{progress.completedSessions} <span className="text-sm font-normal text-slate-400">/ 5 sessions</span></p><div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/10"><div className="h-full w-3/5 rounded-full bg-amber-300" /></div><p className="mt-3 text-xs leading-5 text-slate-400">{hasProgress ? `${Math.max(0, 5 - progress.completedSessions)} more reps to keep your streak alive.` : "Complete your first session to start your streak."}</p></div></aside>
      <div className="lg:pl-[245px]"><header className="flex items-center justify-between border-b border-[#ded9ce] px-5 py-4 sm:px-8 lg:px-12"><div className="flex items-center gap-3 lg:hidden"><div className="grid h-8 w-8 place-items-center rounded-lg bg-[#172132] text-amber-300"><Sparkles size={15} /></div><p className="font-display text-sm font-bold">Interview Coach</p></div><div className="hidden items-center gap-2 text-sm text-[#77736a] sm:flex"><span className="h-2 w-2 rounded-full bg-emerald-500" />Workspace / <span className="font-semibold text-[#172132]">Overview</span></div><div className="flex items-center gap-2">{authLoading ? <div className="h-9 w-24 animate-pulse rounded-full bg-[#e6e0d5]" /> : isAuthenticated ? <><div className="hidden text-right sm:block"><p className="text-xs font-semibold text-[#172132]">{displayName}</p><p className="text-[10px] text-[#8d897f]">{LOCAL_DEMO_MODE ? "Local demo workspace" : "Personal workspace"}</p></div><button onClick={() => void logout()} className="group flex items-center gap-2 rounded-full border border-[#d8d2c5] bg-[#fffcf6] py-1.5 pl-1.5 pr-3 transition hover:border-[#b7b0a2]" title="Sign out"><div className="grid h-7 w-7 place-items-center rounded-full bg-[#d8cbb5] text-[10px] font-bold text-[#5d4b37]">{userInitials}</div><span className="text-xs font-semibold text-[#5e5b54] group-hover:text-[#172132]">Sign out</span></button></> : LOCAL_DEMO_MODE ? <button onClick={() => { setAuthMode("signin"); setShowAuth(true); }} className="inline-flex items-center gap-2 rounded-full bg-[#172132] px-4 py-2.5 text-xs font-bold text-white shadow-sm transition hover:bg-[#25354d]"><UserRound size={14} />Sign in / Register</button>: <button onClick={() => startLogin()} className="inline-flex items-center gap-2 rounded-full bg-[#172132] px-4 py-2.5 text-xs font-bold text-white shadow-sm transition hover:bg-[#25354d]"><UserRound size={14} />Sign in</button>}</div></header><main className="mx-auto max-w-[1300px] px-5 py-8 sm:px-8 lg:px-12 lg:py-11"><div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end"><div><p className="mb-3 text-[11px] font-bold uppercase tracking-[0.2em] text-[#b47719]">{todayLabel}</p><h1 className="font-display text-3xl font-semibold tracking-tight sm:text-[40px]">{greeting}, <span className="text-[#b47719]">{displayFirstName}.</span></h1><p className="mt-2 text-sm text-[#77736a]">{isAuthenticated ? "Your private practice space is ready. Keep the reps intentional." : "Explore the studio, then sign in to save your practice history."}</p></div><button onClick={() => setShowSetup(true)} className="inline-flex items-center justify-center gap-2 self-start rounded-full bg-[#172132] px-5 py-3 text-sm font-bold text-white shadow-lg shadow-[#172132]/15 transition hover:-translate-y-0.5 hover:bg-[#25354d] sm:self-auto"><Play size={16} fill="currentColor" />Start a practice</button></div>
          <section className="mt-9 grid gap-4 sm:grid-cols-3"><div className="rounded-[22px] border border-[#dfd9cc] bg-[#fffcf6] p-5 shadow-sm"><div className="flex items-center justify-between"><p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[#8d897f]">Readiness score</p><TrendingUp size={17} className="text-emerald-600" /></div><div className="mt-4 flex items-end gap-2"><p className="font-display text-4xl font-semibold">{progress.averageScore ?? "—"}</p><p className="mb-1.5 text-sm font-semibold text-[#8d897f]">{hasProgress ? "Based on completed answers" : "Complete a session to begin"}</p></div><div className="mt-4 h-1.5 overflow-hidden rounded-full bg-[#ece7dc]"><div className="h-full rounded-full bg-[#172132]" style={{ width: `${progress.averageScore ?? 0}%` }} /></div></div><div className="rounded-[22px] border border-[#dfd9cc] bg-[#fffcf6] p-5 shadow-sm"><div className="flex items-center justify-between"><p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[#8d897f]">Practice streak</p><Flame size={17} className="text-orange-500" /></div><div className="mt-4 flex items-end gap-2"><p className="font-display text-4xl font-semibold">{progress.streak}</p><p className="mb-1.5 text-sm text-[#8d897f]">{progress.streak === 1 ? "day" : "days"} in a row</p></div><div className="mt-4 flex gap-1.5">{streakDots.map((done, index) => <span key={index} className={`h-1.5 flex-1 rounded-full ${done ? "bg-orange-400" : "bg-[#ece7dc]"}`} />)}</div></div><div className="rounded-[22px] border border-[#dfd9cc] bg-[#fffcf6] p-5 shadow-sm"><div className="flex items-center justify-between"><p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[#8d897f]">Focus area</p><Target size={17} className="text-violet-500" /></div><div className="mt-4 flex items-end gap-2"><p className="font-display text-2xl font-semibold">{progress.focusArea ?? "Not set"}</p></div><p className="mt-3 text-xs leading-5 text-[#8d897f]">{progress.focusArea ? "Based on your lowest average coaching score." : "Your focus area will appear after your first completed answer."}</p></div></section>
          <section className="mt-8 grid gap-6 xl:grid-cols-[1.25fr_0.75fr]"><div className="rounded-[26px] border border-[#dfd9cc] bg-[#fffcf6] p-6 shadow-sm sm:p-7"><div className="flex items-start justify-between"><div><p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#8d897f]">Your momentum</p><h2 className="mt-2 font-display text-xl font-semibold">Readiness over time</h2></div><button onClick={() => setNotice("Trend filters are coming soon.")} className="rounded-full p-2 text-[#8d897f] transition hover:bg-[#f2eee5]"><MoreHorizontal size={18} /></button></div><div className="mt-7 flex h-[180px] items-end justify-start gap-2 sm:gap-3">{chartBars.map((height, index) => <div key={index} className="group flex flex-col items-center gap-2"><div className="relative flex h-[145px] w-12 items-end sm:w-16"><div className={`w-full rounded-t-md transition-all duration-300 group-hover:bg-[#b47719] ${index >= chartBars.length - 3 ? "bg-[#172132]" : "bg-[#d8d2c5]"}`} style={{ height: `${height}%` }} /></div><span className="text-[10px] text-[#aaa59a]">{index % 3 === 0 ? `W${index / 3 + 1}` : ""}</span></div>)}</div><div className="mt-6 flex items-center gap-6 border-t border-[#eee9df] pt-4 text-xs text-[#8d897f]"><span className="flex items-center gap-2"><i className="h-2 w-2 rounded-full bg-[#172132]" />Your score</span><span className="flex items-center gap-2"><i className="h-2 w-2 rounded-full bg-[#d8d2c5]" />Earlier answers</span></div></div><div className="rounded-[26px] bg-[#172132] p-6 text-white shadow-xl shadow-[#172132]/15 sm:p-7"><div className="flex items-center justify-between"><div className="grid h-10 w-10 place-items-center rounded-2xl bg-amber-300 text-[#172132]"><Trophy size={19} /></div><span className="rounded-full bg-white/10 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-slate-300">This week</span></div><h2 className="mt-8 font-display text-2xl font-semibold leading-tight">One good rep<br /><span className="text-amber-300">changes the next one.</span></h2><p className="mt-4 text-sm leading-6 text-slate-400">Practice the question you’re avoiding. That’s usually where the confidence is hiding.</p><button onClick={() => setShowSetup(true)} className="mt-7 flex items-center gap-2 text-sm font-bold text-amber-300 transition hover:text-amber-200">Choose a question <ChevronRight size={16} /></button></div></section>
          <section className="mt-8 rounded-[26px] border border-[#dfd9cc] bg-[#fffcf6] p-6 shadow-sm sm:p-7"><div className="flex items-end justify-between"><div><p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#8d897f]">Recent sessions</p><h2 className="mt-2 font-display text-xl font-semibold">A little proof of progress</h2></div><button onClick={() => setNotice("Your completed sessions will appear here.")} className="flex items-center gap-1 text-xs font-bold text-[#b47719]">View all <ArrowUpRight size={14} /></button></div><div className="mt-5 divide-y divide-[#eee9df]">{progress.recentSessions.length > 0 ? progress.recentSessions.map(session => <div key={`${session.role}-${session.date}`} className="flex flex-col gap-4 py-4 first:pt-2 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-xl text-xs font-bold" style={{ backgroundColor: `${session.accent}22`, color: session.accent }}>{initials(session.role)}</div><div><p className="text-sm font-semibold">{session.role}</p><p className="mt-1 text-xs text-[#8d897f]">{session.type} · {session.date} · 8 min</p></div></div><div className="flex items-center gap-5"><div className="hidden text-right sm:block"><p className="text-[10px] uppercase tracking-[0.14em] text-[#aaa59a]">Coach score</p><p className={`mt-1 font-display text-lg font-semibold ${session.score >= 85 ? "text-emerald-600" : "text-[#b47719]"}`}>{session.score}<span className="ml-1 text-xs font-normal text-[#aaa59a]">/100</span></p></div><button onClick={() => { setSelectedRole(session.role); setInterviewType(session.type.toLowerCase() as "technical" | "behavioral" | "mixed"); setShowSetup(true); }} className="grid h-9 w-9 place-items-center rounded-full border border-[#ded9ce] text-[#77736a] transition hover:bg-[#f2eee5] hover:text-[#172132]"><ChevronRight size={16} /></button></div></div>) : <div className="rounded-2xl border border-dashed border-[#d8d2c5] px-5 py-8 text-center"><p className="text-sm font-semibold text-[#5e5b54]">No completed sessions yet</p><p className="mt-1 text-xs text-[#8d897f]">Start a practice to build your personal interview history.</p><button onClick={() => setShowSetup(true)} className="mt-4 rounded-full bg-[#172132] px-4 py-2 text-xs font-bold text-white">Start your first session</button></div>}</div></section>
          {notice && <div className="fixed bottom-5 left-1/2 z-40 flex -translate-x-1/2 items-center gap-2 rounded-full bg-[#172132] px-4 py-3 text-xs font-medium text-white shadow-xl"><Check size={14} className="text-emerald-300" />{notice}<button onClick={() => setNotice("")} className="ml-2 text-slate-400 hover:text-white"><X size={14} /></button></div>}
        </main></div>
      {showAuth && <div className="fixed inset-0 z-[60] grid place-items-center bg-[#111827]/40 p-5 backdrop-blur-sm"><div className="w-full max-w-[420px] rounded-[26px] bg-[#fffcf6] p-6 shadow-2xl sm:p-7"><div className="flex items-start justify-between"><div><p className="text-[11px] font-bold uppercase tracking-[0.2em] text-[#b47719]">Private local account</p><h2 className="mt-2 font-display text-2xl font-semibold">{authMode === "register" ? "Create your account" : "Welcome back"}</h2><p className="mt-2 text-sm text-[#77736a]">Your account and progress stay in this browser.</p></div><button onClick={() => setShowAuth(false)} className="rounded-full p-2 text-[#8d897f] hover:bg-[#f2eee5]"><X size={18} /></button></div><form onSubmit={submitAuth} className="mt-6 space-y-3">{authMode === "register" && <input value={authName} onChange={event => setAuthName(event.target.value)} placeholder="Your name" autoComplete="name" className="w-full rounded-xl border border-[#d8d2c5] bg-white px-4 py-3 text-sm outline-none focus:border-[#b47719]" required />}{authMode === "register" && <p className="text-xs text-[#8d897f]">Use your own details. No demo user is created.</p>}<input value={authEmail} onChange={event => setAuthEmail(event.target.value)} type="email" placeholder="Email address" autoComplete="email" className="w-full rounded-xl border border-[#d8d2c5] bg-white px-4 py-3 text-sm outline-none focus:border-[#b47719]" required /><input value={authPassword} onChange={event => setAuthPassword(event.target.value)} type="password" placeholder="Password (minimum 6 characters)" autoComplete={authMode === "register" ? "new-password" : "current-password"} className="w-full rounded-xl border border-[#d8d2c5] bg-white px-4 py-3 text-sm outline-none focus:border-[#b47719]" required />{authError && <p className="rounded-xl bg-rose-50 px-3 py-2 text-xs font-medium text-rose-700">{authError instanceof Error ? authError.message : "Please check your details."}</p>}<button type="submit" disabled={authSubmitting} className="w-full rounded-full bg-[#172132] py-3 text-sm font-bold text-white transition hover:bg-[#25354d] disabled:opacity-60">{authSubmitting ? "Please wait…" : authMode === "register" ? "Create account" : "Sign in"}</button></form><button onClick={() => setAuthMode(authMode === "register" ? "signin" : "register")} className="mt-5 w-full text-center text-xs font-semibold text-[#b47719]">{authMode === "register" ? "Already have an account? Sign in" : "New here? Create an account"}</button></div></div>}{showSetup && <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#111827]/40 p-0 backdrop-blur-sm sm:items-center sm:p-5"><div className="w-full max-h-[calc(100vh-1.5rem)] w-full max-w-[640px] overflow-y-auto rounded-t-[28px] bg-[#fffcf6] p-5 pb-6 shadow-2xl sm:rounded-[28px] sm:p-6"><div className="flex items-start justify-between"><div><p className="text-[11px] font-bold uppercase tracking-[0.2em] text-[#b47719]">New practice</p><h2 className="mt-2 font-display text-2xl font-semibold">Set your intention.</h2><p className="mt-2 text-sm text-[#77736a]">A focused 8-minute rep beats an hour of passive prep.</p></div><button onClick={() => setShowSetup(false)} className="rounded-full p-2 text-[#8d897f] hover:bg-[#f2eee5]"><X size={18} /></button></div><div className="mt-7"><p className="mb-3 text-xs font-bold uppercase tracking-[0.16em] text-[#8d897f]">Choose a role</p><div className="grid grid-cols-2 gap-2 sm:grid-cols-3">{roles.map(role => <button key={role.name} onClick={() => setSelectedRole(role.name)} className={`h-[92px] rounded-2xl border p-2.5 text-left transition ${selectedRole === role.name ? "border-[#172132] bg-[#172132] text-white" : "border-[#ded9ce] bg-white text-[#172132] hover:border-[#b7b0a2]"}`}><span className="mb-2 grid h-7 w-7 place-items-center rounded-lg text-[10px] font-bold" style={{ backgroundColor: selectedRole === role.name ? `${role.accent}33` : `${role.accent}22`, color: role.accent }}>{role.short}</span><p className="text-xs font-bold leading-4">{role.name}</p><p className={`mt-1 text-[10px] leading-4 ${selectedRole === role.name ? "text-slate-400" : "text-[#8d897f]"}`}>{role.description}</p></button>)}</div></div><div className="mt-6 grid gap-5 sm:grid-cols-3"><div><p className="mb-3 text-xs font-bold uppercase tracking-[0.16em] text-[#8d897f]">Interview type</p><div className="flex flex-wrap gap-2">{(["mixed", "technical", "behavioral"] as const).map(type => <button key={type} onClick={() => setInterviewType(type)} className={`rounded-full px-3 py-2 text-xs font-semibold capitalize transition ${interviewType === type ? "bg-[#172132] text-white" : "bg-[#f0ece3] text-[#77736a] hover:bg-[#e5dfd2]"}`}>{type}</button>)}</div></div><div><p className="mb-3 text-xs font-bold uppercase tracking-[0.16em] text-[#8d897f]">Difficulty</p><div className="flex flex-wrap gap-2">{(["warmup", "standard", "stretch"] as const).map(level => <button key={level} onClick={() => setDifficulty(level)} className={`rounded-full px-3 py-2 text-xs font-semibold capitalize transition ${difficulty === level ? "bg-amber-300 text-[#172132]" : "bg-[#f0ece3] text-[#77736a] hover:bg-[#e5dfd2]"}`}>{level}</button>)}</div></div></div><div><p className="mb-3 text-xs font-bold uppercase tracking-[0.16em] text-[#8d897f]">Session length</p><div className="flex flex-wrap gap-2">{[3, 5, 8].map(count => <button key={count} onClick={() => setTotalQuestions(count)} className={`rounded-full px-3 py-2 text-xs font-semibold transition ${totalQuestions === count ? "bg-amber-300 text-[#172132]" : "bg-[#f0ece3] text-[#77736a] hover:bg-[#e5dfd2]"}`}>{count} questions</button>)}</div><p className="mt-2 text-[10px] text-[#8d897f]">About {totalQuestions * 2}–{totalQuestions * 3} minutes</p></div><button onClick={startPractice} disabled={generateQuestion.isPending} className="sticky bottom-0 z-10 mt-5 flex w-full items-center justify-center gap-2 rounded-full border-4 border-[#fffcf6] bg-[#172132] py-3.5 text-sm font-bold text-white transition hover:bg-[#25354d] disabled:opacity-70">{generateQuestion.isPending ? <RefreshCw size={16} className="animate-spin" /> : <Zap size={16} className="text-amber-300" />}Start focused practice <ArrowUpRight size={16} /></button></div></div>}
    </div>
  );
}
